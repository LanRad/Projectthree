#this script is simple, it will delete any numerical data equal to 420.
# marijuana is bad for you