# radford.pkg

## Math-a-magical™

This vrey amature R-package aims to help you with displaying and helping you understand your data frames better! Weather that be displaying a graph or creating a linear model, whatever your need let Math-a-magical™ be your wand!